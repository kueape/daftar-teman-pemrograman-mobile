import react from 'react';
import {View,Text,FlatList,Image,StyleSheet,Button} from 'react-native';
import {useNavigation} from '@react-navigation/native';

const listkontak = [
  {id: '1', name: 'Lulu', phone: '08123456789', details: 'ceo', address: 'Serang', image: require('../assets/llckp.jpg')},
  {id: '1', name: 'Jesslyn', phone: '08123456788', details: 'Hrd', address: 'Malang', image: require('../assets/2.jpg')},
  {id: '1', name: 'Jessica', phone: '08123456787', details: 'Admin', address: 'Bandung', image: require('../assets/3.jpg')},
  {id: '1', name: 'Lana', phone: '08123456786', details: 'CS', address: 'Bekasi', image: require('../assets/4.jpg')},
  {id: '1', name: 'Nachia', phone: '08123456785', details: 'Admin', address: 'Bogor', image: require('../assets/5.jpg')},
];


const Kontak = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <FlatList
        data={listkontak}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Image source={item.image} style={styles.image} />
            <View style={styles.info}>
              <Text style={styles.name}>{item.name}</Text>
              <Text>{item.address}</Text>
              <Button
                title="View Details"
                onPress={() => navigation.navigate('Detailkontak', { contact: item })}
              />
            </View>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  item: {
    flexDirection: 'row',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    alignItems: 'center',
  },
  image: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 15,
  },
  info: {
    flex: 1,
  },
  name: {
    fontSize: 18,
  },
});

export default Kontak;